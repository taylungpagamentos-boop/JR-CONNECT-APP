package com.jrconnect.app.adapter

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.jrconnect.app.R
import com.jrconnect.app.api.models.Category
import com.jrconnect.app.utils.NetworkUtils

class ConfigAdapter(
    private val onItemClick: (Category) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        const val VIEW_TYPE_HEADER = 0
        const val VIEW_TYPE_ITEM = 1
    }

    sealed class ListItem {
        data class Header(val title: String, val color: Int) : ListItem()
        data class ConfigItem(val category: Category) : ListItem()
    }

    private val items = mutableListOf<ListItem>()

    fun setCategories(categories: List<Category>) {
        items.clear()
        val grouped = mutableMapOf<String, MutableList<Category>>()

        // Agrupa as categorias pelo campo "group" ou pelo nome do operador
        for (category in categories) {
            val groupKey = when {
                category.group.isNotEmpty() -> category.group
                else -> inferGroup(category.name)
            }
            grouped.getOrPut(groupKey) { mutableListOf() }.add(category)
        }

        // Ordem preferencial de operadoras
        val operatorOrder = listOf("VIVO", "TIM", "CLARO", "OI")
        val sortedGroups = grouped.entries.sortedWith(Comparator { a, b ->
            val aIdx = operatorOrder.indexOfFirst { a.key.contains(it, true) }
            val bIdx = operatorOrder.indexOfFirst { b.key.contains(it, true) }
            val ai = if (aIdx < 0) 99 else aIdx
            val bi = if (bIdx < 0) 99 else bIdx
            if (ai != bi) ai - bi else a.key.compareTo(b.key)
        })

        for ((groupName, cats) in sortedGroups) {
            val operatorColor = NetworkUtils.getOperatorColor(
                NetworkUtils.getOperatorFromCategoryName(groupName)
            )
            items.add(ListItem.Header(groupName, operatorColor))
            cats.sortedBy { it.name }.forEach { cat ->
                items.add(ListItem.ConfigItem(cat))
            }
        }
        notifyDataSetChanged()
    }

    private fun inferGroup(name: String): String {
        return when {
            name.contains("VIVO", true) && name.contains("GCLOUD", true) -> "🔵 VIVO G-CLOUD"
            name.contains("VIVO", true) && name.contains("FLARE", true) -> "🟣 VIVO PRÉ | PÓS | EXPIRADO"
            name.contains("VIVO", true) && name.contains("SECURITY", true) -> "🟣 VIVO SECURITY"
            name.contains("VIVO", true) && name.contains("V2RAY", true) -> "🟣 VIVO V2RAY EASY | CONTROLE"
            name.contains("TIM", true) && name.contains("GCLOUD", true) -> "🔵 TIM GCLOUD | SLOW"
            name.contains("TIM", true) && name.contains("FRONT", true) -> "🔵 TIM FRONT 🔥"
            name.contains("TIM", true) && name.contains("FLARE", true) -> "🔵 TIM FLARE | ✈ MODO AVIÃO"
            name.contains("TIM", true) && name.contains("XRAY", true) -> "🔵 TIM XRAY 🔥"
            name.contains("TIM", true) && name.contains("CDN", true) -> "🔵 TIM CDN FRONT"
            name.contains("TIM", true) && name.contains("SLOW", true) -> "🔵 TIM GCLOUD | SLOW"
            name.contains("CLARO", true) -> "🔴 CLARO PRÉ PAGO | PLANOS"
            name.contains("OI", true) -> "🟢 OI"
            else -> "🔵 OUTROS"
        }
    }

    override fun getItemViewType(position: Int): Int {
        return when (items[position]) {
            is ListItem.Header -> VIEW_TYPE_HEADER
            is ListItem.ConfigItem -> VIEW_TYPE_ITEM
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == VIEW_TYPE_HEADER) {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_config_header, parent, false)
            HeaderViewHolder(view)
        } else {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_config, parent, false)
            ItemViewHolder(view)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (val item = items[position]) {
            is ListItem.Header -> (holder as HeaderViewHolder).bind(item)
            is ListItem.ConfigItem -> (holder as ItemViewHolder).bind(item.category)
        }
    }

    override fun getItemCount() = items.size

    // ─── ViewHolder: Cabeçalho ────────────────────────────────────────────────
    inner class HeaderViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val tvTitle: TextView = view.findViewById(R.id.tvHeaderTitle)
        private val vLine: View = view.findViewById(R.id.vHeaderLine)

        fun bind(header: ListItem.Header) {
            tvTitle.text = header.title
            vLine.setBackgroundColor(header.color)
        }
    }

    // ─── ViewHolder: Item de Configuração ────────────────────────────────────
    inner class ItemViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val ivIcon: ImageView = view.findViewById(R.id.ivOperatorIcon)
        private val tvName: TextView = view.findViewById(R.id.tvConfigName)
        private val tvSubtitle: TextView = view.findViewById(R.id.tvConfigSubtitle)
        private val vIndicator: View = view.findViewById(R.id.vColorIndicator)

        fun bind(category: Category) {
            tvName.text = category.name
            tvSubtitle.text = category.description.ifEmpty { category.type }

            // Define ícone conforme operadora
            val iconRes = when {
                category.name.contains("VIVO", true) -> R.drawable.ic_vivo
                category.name.contains("TIM", true) -> R.drawable.ic_tim
                category.name.contains("CLARO", true) -> R.drawable.ic_claro
                category.name.contains("OI", true) -> R.drawable.ic_oi
                else -> R.drawable.ic_default_operator
            }
            ivIcon.setImageResource(iconRes)

            // Cor do indicador
            val operatorColor = NetworkUtils.getOperatorColor(
                NetworkUtils.getOperatorFromCategoryName(category.name)
            )
            vIndicator.setBackgroundColor(operatorColor)

            itemView.setOnClickListener { onItemClick(category) }
        }
    }
}
