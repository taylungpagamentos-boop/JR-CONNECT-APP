package com.jrconnect.app.api

import com.jrconnect.app.api.models.*
import retrofit2.Response
import retrofit2.http.*

interface ApiService {

    // ==================== AUTENTICAÇÃO ====================
    @GET("api/auth/sse-token")
    suspend fun getSseToken(): Response<SseTokenResponse>

    @POST("api/auth/login")
    suspend fun loginClient(
        @Body request: ClientLoginRequest
    ): Response<ClientLoginResponse>

    // ==================== CLIENTES ====================
    @GET("api/clients")
    suspend fun getClients(
        @Query("username") username: String? = null,
        @Query("search") search: String? = null,
        @Query("page") page: Int? = null,
        @Query("limit") limit: Int? = null
    ): Response<ApiListResponse<Client>>

    @POST("api/clients")
    suspend fun createClient(
        @Body client: Map<String, Any>
    ): Response<ApiResponse<Client>>

    @GET("api/clients/{id}")
    suspend fun getClientById(
        @Path("id") id: Int
    ): Response<ApiResponse<Client>>

    @PUT("api/clients/{id}")
    suspend fun updateClient(
        @Path("id") id: Int,
        @Body client: Map<String, Any>
    ): Response<ApiResponse<Client>>

    @DELETE("api/clients/{id}")
    suspend fun deleteClient(
        @Path("id") id: Int
    ): Response<ApiResponse<Any>>

    @POST("api/clients/{id}/renew")
    suspend fun renewClient(
        @Path("id") id: Int,
        @Body body: Map<String, Any> = emptyMap()
    ): Response<ApiResponse<Client>>

    @PUT("api/clients/{id}/suspend")
    suspend fun suspendClient(
        @Path("id") id: Int
    ): Response<ApiResponse<Client>>

    // ==================== CATEGORIAS ====================
    @GET("api/categories")
    suspend fun getCategories(): Response<ApiListResponse<Category>>

    @GET("api/categories/{id}")
    suspend fun getCategoryById(
        @Path("id") id: Int
    ): Response<ApiResponse<Category>>

    // ==================== REVENDEDORES ====================
    @GET("api/resellers")
    suspend fun getResellers(): Response<ApiListResponse<Any>>
}
