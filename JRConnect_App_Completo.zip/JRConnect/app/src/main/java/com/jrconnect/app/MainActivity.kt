package com.jrconnect.app

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.VpnService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.method.PasswordTransformationMethod
import android.text.method.SingleLineTransformationMethod
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.jrconnect.app.api.ApiClient
import com.jrconnect.app.api.models.Category
import com.jrconnect.app.api.models.ClientLoginRequest
import com.jrconnect.app.databinding.ActivityMainBinding
import com.jrconnect.app.utils.NetworkUtils
import com.jrconnect.app.vpn.JrVpnService
import kotlinx.coroutines.launch
import java.util.Timer
import java.util.TimerTask

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var selectedCategory: Category? = null
    private var isConnected = false
    private var passwordVisible = false
    private var pingTimer: Timer? = null
    private val handler = Handler(Looper.getMainLooper())

    // Resultado do pedido de permissão VPN
    private val vpnPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            startVpnConnection()
        } else {
            showToast("Permissão VPN negada. Necessária para conectar.")
        }
    }

    // BroadcastReceiver para atualizar status da VPN
    private val vpnStatusReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                "com.jrconnect.app.VPN_CONNECTED" -> updateStatus(true)
                "com.jrconnect.app.VPN_DISCONNECTED" -> updateStatus(false)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupUI()
        startNetworkInfoUpdater()
    }

    private fun setupUI() {
        // ─── Botão: Escolher Configuração ────────────────────────────────────
        binding.btnChooseConfig.setOnClickListener {
            val intent = Intent(this, ConfigSelectionActivity::class.java)
            startActivityForResult(intent, REQUEST_CONFIG)
        }

        // ─── Botão: Mostrar/Ocultar Senha ────────────────────────────────────
        binding.ivPasswordToggle.setOnClickListener {
            passwordVisible = !passwordVisible
            if (passwordVisible) {
                binding.etPassword.transformationMethod = SingleLineTransformationMethod.getInstance()
                binding.ivPasswordToggle.setImageResource(R.drawable.ic_eye_open)
            } else {
                binding.etPassword.transformationMethod = PasswordTransformationMethod.getInstance()
                binding.ivPasswordToggle.setImageResource(R.drawable.ic_eye_closed)
            }
            binding.etPassword.setSelection(binding.etPassword.text?.length ?: 0)
        }

        // ─── Botão: INICIAR / PARAR ──────────────────────────────────────────
        binding.btnConnect.setOnClickListener {
            if (isConnected) {
                disconnectVpn()
            } else {
                validateAndConnect()
            }
        }

        // ─── Botão: Atualizar ────────────────────────────────────────────────
        binding.btnRefresh.setOnClickListener {
            updateNetworkInfo()
            showToast("Informações atualizadas!")
        }

        // ─── Botão: Copiar usuário ───────────────────────────────────────────
        binding.btnCopy.setOnClickListener {
            val user = binding.etUsername.text?.toString() ?: ""
            if (user.isNotEmpty()) {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("usuario", user))
                showToast("Usuário copiado!")
            } else {
                showToast("Digite um usuário primeiro")
            }
        }

        // ─── Botão: Config extra ────────────────────────────────────────────
        binding.btnExtraConfig.setOnClickListener {
            showToast("Configuração avançada - Em breve!")
        }

        // ─── Botão: COMPRAR / RENOVAR ────────────────────────────────────────
        binding.btnBuy.setOnClickListener {
            openWhatsApp()
        }

        // ─── Botão: SUPORTE WhatsApp ─────────────────────────────────────────
        binding.btnSupport.setOnClickListener {
            openWhatsApp()
        }

        // Estado inicial
        updateStatus(false)
        updateNetworkInfo()
    }

    private fun validateAndConnect() {
        val username = binding.etUsername.text?.toString()?.trim() ?: ""
        val password = binding.etPassword.text?.toString() ?: ""

        if (selectedCategory == null) {
            showToast("⚠️ Escolha uma configuração primeiro!")
            return
        }
        if (username.isEmpty()) {
            showToast("⚠️ Digite seu nome de usuário!")
            binding.etUsername.requestFocus()
            return
        }
        if (password.isEmpty()) {
            showToast("⚠️ Digite sua senha!")
            binding.etPassword.requestFocus()
            return
        }

        // Mostra progresso
        setConnectingState()

        lifecycleScope.launch {
            try {
                // Tenta autenticar via API
                val response = ApiClient.apiService.getClients(username = username)
                if (response.isSuccessful) {
                    val clients = response.body()?.data ?: emptyList()
                    val client = clients.firstOrNull {
                        it.username.equals(username, ignoreCase = true)
                    }

                    when {
                        client == null -> {
                            runOnUiThread {
                                resetConnectButton()
                                showToast("❌ Usuário não encontrado!")
                            }
                        }
                        !client.active -> {
                            runOnUiThread {
                                resetConnectButton()
                                showToast("❌ Conta desativada ou expirada!")
                            }
                        }
                        else -> {
                            runOnUiThread {
                                // Credenciais válidas, inicia VPN
                                requestVpnPermission()
                            }
                        }
                    }
                } else {
                    // Se API falhar, tenta conectar mesmo assim
                    runOnUiThread { requestVpnPermission() }
                }
            } catch (e: Exception) {
                // Sem internet, mas tenta conectar
                runOnUiThread { requestVpnPermission() }
            }
        }
    }

    private fun requestVpnPermission() {
        val intent = VpnService.prepare(this)
        if (intent != null) {
            vpnPermissionLauncher.launch(intent)
        } else {
            startVpnConnection()
        }
    }

    private fun startVpnConnection() {
        val category = selectedCategory ?: return
        val username = binding.etUsername.text?.toString()?.trim() ?: ""
        val password = binding.etPassword.text?.toString() ?: ""

        val serviceIntent = Intent(this, JrVpnService::class.java).apply {
            action = JrVpnService.ACTION_START
            putExtra(JrVpnService.EXTRA_SERVER_HOST, category.host)
            putExtra(JrVpnService.EXTRA_SERVER_PORT, category.port)
            putExtra(JrVpnService.EXTRA_USERNAME, username)
            putExtra(JrVpnService.EXTRA_PASSWORD, password)
            putExtra(JrVpnService.EXTRA_PROTOCOL, category.protocol.ifEmpty { category.type })
            putExtra(JrVpnService.EXTRA_UUID, category.uuid)
            putExtra(JrVpnService.EXTRA_SNI, category.sni)
            putExtra(JrVpnService.EXTRA_CONFIG_NAME, category.name)
        }
        startService(serviceIntent)

        // Simula o processo de conexão (aguarda resposta real do serviço)
        handler.postDelayed({
            updateStatus(true)
            showToast("✅ Conectado com sucesso!")
        }, 2000)
    }

    private fun disconnectVpn() {
        val serviceIntent = Intent(this, JrVpnService::class.java).apply {
            action = JrVpnService.ACTION_STOP
        }
        startService(serviceIntent)
        updateStatus(false)
        showToast("Desconectado!")
    }

    private fun setConnectingState() {
        binding.btnConnect.text = "CONECTANDO..."
        binding.btnConnect.isEnabled = false
        binding.tvStatus.text = "CONECTANDO..."
        binding.tvStatus.setTextColor(getColor(R.color.status_connecting))
    }

    private fun resetConnectButton() {
        binding.btnConnect.text = "INICIAR"
        binding.btnConnect.isEnabled = true
        updateStatus(false)
    }

    private fun updateStatus(connected: Boolean) {
        isConnected = connected
        if (connected) {
            binding.tvStatus.text = "CONECTADO"
            binding.tvStatus.setTextColor(getColor(R.color.status_connected))
            binding.btnConnect.text = "PARAR"
            binding.btnConnect.isEnabled = true
            binding.viewStatusBar.setBackgroundColor(getColor(R.color.status_connected_bg))
        } else {
            binding.tvStatus.text = "DESCONECTADO"
            binding.tvStatus.setTextColor(getColor(R.color.status_disconnected))
            binding.btnConnect.text = "INICIAR"
            binding.btnConnect.isEnabled = true
            binding.viewStatusBar.setBackgroundColor(getColor(R.color.status_disconnected_bg))
        }
    }

    private fun updateNetworkInfo() {
        val ip = NetworkUtils.getWifiIpAddress(this)
        binding.tvWifiIp.text = "WiFi: $ip"

        // Medir ping de forma assíncrona
        lifecycleScope.launch {
            val ping = measurePing()
            binding.tvPing.text = "Ping: ${ping}ms"
        }
    }

    private suspend fun measurePing(): Long {
        return try {
            val start = System.currentTimeMillis()
            val process = Runtime.getRuntime().exec("ping -c 1 -W 1 8.8.8.8")
            process.waitFor()
            val elapsed = System.currentTimeMillis() - start
            if (elapsed > 1000) 0L else elapsed
        } catch (e: Exception) {
            0L
        }
    }

    private fun startNetworkInfoUpdater() {
        pingTimer = Timer()
        pingTimer?.scheduleAtFixedRate(object : TimerTask() {
            override fun run() {
                runOnUiThread { updateNetworkInfo() }
            }
        }, 0, 5000) // Atualiza a cada 5 segundos
    }

    private fun openWhatsApp() {
        val url = "https://wa.me/qr/E7XKJ3DND6CMI1"
        try {
            val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url))
            startActivity(intent)
        } catch (e: Exception) {
            showToast("Não foi possível abrir o WhatsApp")
        }
    }

    private fun showToast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CONFIG && resultCode == Activity.RESULT_OK) {
            val categoryId = data?.getIntExtra("category_id", -1) ?: -1
            val categoryName = data?.getStringExtra("category_name") ?: ""
            val categoryDesc = data?.getStringExtra("category_description") ?: ""
            val categoryHost = data?.getStringExtra("category_host") ?: ""
            val categoryPort = data?.getIntExtra("category_port", 0) ?: 0
            val categoryProtocol = data?.getStringExtra("category_protocol") ?: ""
            val categoryUuid = data?.getStringExtra("category_uuid") ?: ""
            val categorySni = data?.getStringExtra("category_sni") ?: ""
            val categoryType = data?.getStringExtra("category_type") ?: ""

            selectedCategory = Category(
                id = categoryId,
                name = categoryName,
                description = categoryDesc,
                host = categoryHost,
                port = categoryPort,
                protocol = categoryProtocol,
                uuid = categoryUuid,
                sni = categorySni,
                type = categoryType
            )
            binding.btnChooseConfig.text = "  $categoryName"
        }
    }

    override fun onResume() {
        super.onResume()
        val filter = IntentFilter().apply {
            addAction("com.jrconnect.app.VPN_CONNECTED")
            addAction("com.jrconnect.app.VPN_DISCONNECTED")
        }
        registerReceiver(vpnStatusReceiver, filter)
        updateStatus(JrVpnService.isRunning)
    }

    override fun onPause() {
        super.onPause()
        try { unregisterReceiver(vpnStatusReceiver) } catch (e: Exception) {}
    }

    override fun onDestroy() {
        pingTimer?.cancel()
        super.onDestroy()
    }

    companion object {
        const val REQUEST_CONFIG = 100
    }
}
