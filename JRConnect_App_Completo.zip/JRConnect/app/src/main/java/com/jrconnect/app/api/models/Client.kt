package com.jrconnect.app.api.models

import com.google.gson.annotations.SerializedName

data class Client(
    @SerializedName("id") val id: Int = 0,
    @SerializedName("username") val username: String = "",
    @SerializedName("password") val password: String = "",
    @SerializedName("name") val name: String = "",
    @SerializedName("status") val status: String = "",
    @SerializedName("active") val active: Boolean = false,
    @SerializedName("expiry_date") val expiryDate: String = "",
    @SerializedName("expires_at") val expiresAt: String = "",
    @SerializedName("connection_limit") val connectionLimit: Int = 1,
    @SerializedName("connections") val connections: Int = 0,
    @SerializedName("reseller_id") val resellerId: Int = 0,
    @SerializedName("category_id") val categoryId: Int = 0,
    @SerializedName("uuid") val uuid: String = ""
)

data class ClientLoginRequest(
    @SerializedName("username") val username: String,
    @SerializedName("password") val password: String
)

data class ClientLoginResponse(
    @SerializedName("success") val success: Boolean = false,
    @SerializedName("message") val message: String = "",
    @SerializedName("client") val client: Client? = null,
    @SerializedName("token") val token: String = "",
    @SerializedName("config") val config: String = ""
)
