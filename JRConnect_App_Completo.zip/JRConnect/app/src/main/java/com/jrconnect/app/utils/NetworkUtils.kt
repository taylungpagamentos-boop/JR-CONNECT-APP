package com.jrconnect.app.utils

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.InetAddress
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*

object NetworkUtils {

    fun getWifiIpAddress(context: Context): String {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val interfaces = NetworkInterface.getNetworkInterfaces()
                for (intf in Collections.list(interfaces)) {
                    val addrs = intf.inetAddresses
                    for (addr in Collections.list(addrs)) {
                        if (!addr.isLoopbackAddress && addr is Inet4Address) {
                            return addr.hostAddress ?: "0.0.0.0"
                        }
                    }
                }
                "0.0.0.0"
            } else {
                @Suppress("DEPRECATION")
                val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                @Suppress("DEPRECATION")
                val ipInt = wifiManager.connectionInfo.ipAddress
                if (ipInt == 0) "0.0.0.0"
                else String.format(
                    "%d.%d.%d.%d",
                    ipInt and 0xff,
                    ipInt shr 8 and 0xff,
                    ipInt shr 16 and 0xff,
                    ipInt shr 24 and 0xff
                )
            }
        } catch (e: Exception) {
            "0.0.0.0"
        }
    }

    fun isNetworkAvailable(context: Context): Boolean {
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val network = connectivityManager.activeNetwork ?: return false
            val capabilities = connectivityManager.getNetworkCapabilities(network) ?: return false
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                    capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ||
                    capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
        } else {
            @Suppress("DEPRECATION")
            connectivityManager.activeNetworkInfo?.isConnected == true
        }
    }

    fun formatExpiryDate(dateStr: String): String {
        return try {
            val inputFormats = listOf(
                "yyyy-MM-dd'T'HH:mm:ss.SSSSSS'Z'",
                "yyyy-MM-dd'T'HH:mm:ss'Z'",
                "yyyy-MM-dd HH:mm:ss",
                "yyyy-MM-dd"
            )
            val outputFormat = SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR"))
            var date: Date? = null
            for (format in inputFormats) {
                try {
                    date = SimpleDateFormat(format, Locale.US).parse(dateStr)
                    if (date != null) break
                } catch (e: Exception) { /* continua */ }
            }
            date?.let { outputFormat.format(it) } ?: dateStr
        } catch (e: Exception) {
            dateStr
        }
    }

    fun isExpired(dateStr: String): Boolean {
        return try {
            val inputFormats = listOf(
                "yyyy-MM-dd'T'HH:mm:ss.SSSSSS'Z'",
                "yyyy-MM-dd'T'HH:mm:ss'Z'",
                "yyyy-MM-dd HH:mm:ss",
                "yyyy-MM-dd"
            )
            var date: Date? = null
            for (format in inputFormats) {
                try {
                    date = SimpleDateFormat(format, Locale.US).parse(dateStr)
                    if (date != null) break
                } catch (e: Exception) { /* continua */ }
            }
            date?.before(Date()) ?: false
        } catch (e: Exception) {
            false
        }
    }

    fun getOperatorFromCategoryName(name: String): String {
        return when {
            name.contains("VIVO", ignoreCase = true) -> "VIVO"
            name.contains("TIM", ignoreCase = true) -> "TIM"
            name.contains("CLARO", ignoreCase = true) -> "CLARO"
            name.contains("OI", ignoreCase = true) -> "OI"
            else -> "OUTROS"
        }
    }

    fun getOperatorColor(operator: String): Int {
        return when (operator.uppercase()) {
            "VIVO" -> 0xFF660099.toInt()
            "TIM" -> 0xFF003087.toInt()
            "CLARO" -> 0xFFCC0000.toInt()
            "OI" -> 0xFF00A651.toInt()
            else -> 0xFF333366.toInt()
        }
    }
}
