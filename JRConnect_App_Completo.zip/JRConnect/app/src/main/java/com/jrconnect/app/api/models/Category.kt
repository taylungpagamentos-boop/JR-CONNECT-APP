package com.jrconnect.app.api.models

import com.google.gson.annotations.SerializedName

data class Category(
    @SerializedName("id") val id: Int = 0,
    @SerializedName("name") val name: String = "",
    @SerializedName("description") val description: String = "",
    @SerializedName("group") val group: String = "",
    @SerializedName("operator") val operator: String = "",
    @SerializedName("type") val type: String = "",
    @SerializedName("active") val active: Boolean = true,
    @SerializedName("host") val host: String = "",
    @SerializedName("port") val port: Int = 0,
    @SerializedName("protocol") val protocol: String = "",
    @SerializedName("uuid") val uuid: String = "",
    @SerializedName("sni") val sni: String = "",
    @SerializedName("path") val path: String = "",
    @SerializedName("network") val network: String = "",
    @SerializedName("security") val security: String = "",
    @SerializedName("config") val config: Map<String, Any>? = null,
    @SerializedName("server_config") val serverConfig: String = "",
    @SerializedName("color") val color: String = "#6200EE"
)
