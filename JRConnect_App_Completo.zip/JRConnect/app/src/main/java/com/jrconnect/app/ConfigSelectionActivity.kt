package com.jrconnect.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.jrconnect.app.adapter.ConfigAdapter
import com.jrconnect.app.api.ApiClient
import com.jrconnect.app.api.models.Category
import com.jrconnect.app.databinding.ActivityConfigSelectionBinding
import kotlinx.coroutines.launch

class ConfigSelectionActivity : AppCompatActivity() {

    private lateinit var binding: ActivityConfigSelectionBinding
    private lateinit var adapter: ConfigAdapter
    private val allCategories = mutableListOf<Category>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityConfigSelectionBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()
        setupSearch()
        loadCategories()

        // Botão fechar
        binding.btnClose.setOnClickListener { finish() }
    }

    private fun setupRecyclerView() {
        adapter = ConfigAdapter { category ->
            // Retorna a categoria selecionada para a MainActivity
            val resultIntent = Intent().apply {
                putExtra("category_id", category.id)
                putExtra("category_name", category.name)
                putExtra("category_description", category.description)
                putExtra("category_host", category.host)
                putExtra("category_port", category.port)
                putExtra("category_protocol", category.protocol)
                putExtra("category_uuid", category.uuid)
                putExtra("category_sni", category.sni)
                putExtra("category_type", category.type)
            }
            setResult(Activity.RESULT_OK, resultIntent)
            finish()
        }

        binding.recyclerView.apply {
            layoutManager = LinearLayoutManager(this@ConfigSelectionActivity)
            adapter = this@ConfigSelectionActivity.adapter
        }
    }

    private fun setupSearch() {
        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                filterCategories(s?.toString() ?: "")
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun filterCategories(query: String) {
        val filtered = if (query.isEmpty()) {
            allCategories
        } else {
            allCategories.filter {
                it.name.contains(query, ignoreCase = true) ||
                        it.description.contains(query, ignoreCase = true) ||
                        it.type.contains(query, ignoreCase = true)
            }
        }
        adapter.setCategories(filtered)
    }

    private fun loadCategories() {
        binding.progressBar.visibility = View.VISIBLE
        binding.tvError.visibility = View.GONE

        lifecycleScope.launch {
            try {
                val response = ApiClient.apiService.getCategories()
                binding.progressBar.visibility = View.GONE

                if (response.isSuccessful) {
                    val categories = response.body()?.data ?: emptyList()
                    if (categories.isEmpty()) {
                        // Se API não retornar categorias, usa lista padrão
                        loadDefaultCategories()
                    } else {
                        allCategories.clear()
                        allCategories.addAll(categories)
                        adapter.setCategories(allCategories)
                    }
                } else {
                    loadDefaultCategories()
                }
            } catch (e: Exception) {
                binding.progressBar.visibility = View.GONE
                loadDefaultCategories()
            }
        }
    }

    private fun loadDefaultCategories() {
        // Categorias padrão caso a API não retorne
        val defaults = listOf(
            // VIVO GCloud
            Category(1, "VIVO GCLOUD 1", "G-CLOUD", "VIVO GCLOUD", "VIVO", "gcloud"),
            Category(2, "VIVO GCLOUD 2", "G-CLOUD", "VIVO GCLOUD", "VIVO", "gcloud"),
            // VIVO Flare
            Category(3, "VIVO FLARE 1", "VIVO PRÉ TURBO", "VIVO PRÉ | PÓS | EXPIRADO", "VIVO", "flare"),
            Category(4, "VIVO FLARE 2", "VIVO PRÉ TURBO", "VIVO PRÉ | PÓS | EXPIRADO", "VIVO", "flare"),
            Category(5, "VIVO FLARE 3", "VIVO PRÉ TURBO", "VIVO PRÉ | PÓS | EXPIRADO", "VIVO", "flare"),
            // VIVO Security
            Category(6, "VIVO SECURITY 1", "✈ MODO AVIÃO", "VIVO SECURITY", "VIVO", "security"),
            Category(7, "VIVO SECURITY 2", "✈ MODO AVIÃO", "VIVO SECURITY", "VIVO", "security"),
            Category(8, "VIVO SECURITY 3", "✈ MODO AVIÃO", "VIVO SECURITY", "VIVO", "security"),
            // VIVO V2Ray
            Category(9, "VIVO V2RAY 1", "VIVO EASY", "VIVO V2RAY EASY | CONTROLE", "VIVO", "v2ray"),
            Category(10, "VIVO V2RAY 2", "VIVO EASY", "VIVO V2RAY EASY | CONTROLE", "VIVO", "v2ray"),
            Category(11, "VIVO V2RAY 3", "VIVO EASY", "VIVO V2RAY EASY | CONTROLE", "VIVO", "v2ray"),
            // TIM GCloud
            Category(12, "TIM GCLOUD RÁPIDA", "VALIDO | EXPIRADO", "TIM GCLOUD | SLOW", "TIM", "gcloud"),
            Category(13, "TIM GCLOUD 2", "EXPIRADO & VALIDO", "TIM GCLOUD | SLOW", "TIM", "gcloud"),
            Category(14, "TIM GCLOUD 3", "SALDO VÁLIDO ✅", "TIM GCLOUD | SLOW", "TIM", "gcloud"),
            // TIM Front
            Category(15, "TIM FRONT 1 🔥", "VALIDO/EXPIRADO", "TIM CDN FRONT", "TIM", "front"),
            Category(16, "TIM FRONT 2 🔥", "VALIDO/EXPIRADO", "TIM CDN FRONT", "TIM", "front"),
            Category(17, "TIM FRONT 3 🔥", "VALIDO/EXPIRADO", "TIM CDN FRONT", "TIM", "front"),
            // TIM Flare
            Category(18, "TIM FLARE - SSL 1 🔥", "✈ MODO AVIÃO - SALDO VALIDO", "TIM FLARE | ✈ MODO AVIÃO", "TIM", "flare"),
            Category(19, "TIM FLARE 2 🔥", "✈ MODO AVIÃO - SALDO VALIDO", "TIM FLARE | ✈ MODO AVIÃO", "TIM", "flare"),
            Category(20, "TIM FLARE 3 🔥", "✈ MODO AVIÃO - SALDO VALIDO", "TIM FLARE | ✈ MODO AVIÃO", "TIM", "flare"),
            // TIM XRay
            Category(21, "TIM XRAY 🔥", "USE SEU UUID - VALIDO | EXPIRADO", "TIM XRAY", "TIM", "xray"),
            Category(22, "TIM XRAY - CORE 🔥", "USE SEU UUID - VALIDO | EXPIRADO", "TIM XRAY", "TIM", "xray"),
            Category(23, "TIM XRAY 3", "USE SEU UUID - CÓDIGO", "TIM XRAY", "TIM", "xray"),
            // TIM Slow
            Category(24, "TIM SLOW 1", "Conexão lenta! 🐢", "TIM GCLOUD | SLOW", "TIM", "slow"),
            Category(25, "TIM SLOW 2", "Conexão lenta! 🐢", "TIM GCLOUD | SLOW", "TIM", "slow"),
            Category(26, "TIM SLOW 3", "Conexão lenta! 🐢", "TIM GCLOUD | SLOW", "TIM", "slow"),
            // Claro
            Category(27, "CLARO FLEX -> 80", "✈ MODO AVIÃO", "CLARO PRÉ PAGO | PLANOS", "CLARO", "flex"),
            Category(28, "CLARO FLEX -> 443", "✈ MODO AVIÃO", "CLARO PRÉ PAGO | PLANOS", "CLARO", "flex"),
            Category(29, "CLARO SLOW 1", "Conexão lenta! 🐢", "CLARO PRÉ PAGO | PLANOS", "CLARO", "slow"),
            Category(30, "CLARO SLOW 2", "Conexão lenta! 🐢", "CLARO PRÉ PAGO | PLANOS", "CLARO", "slow")
        )
        allCategories.clear()
        allCategories.addAll(defaults)
        adapter.setCategories(allCategories)
        Toast.makeText(this, "Usando configurações locais", Toast.LENGTH_SHORT).show()
    }
}
