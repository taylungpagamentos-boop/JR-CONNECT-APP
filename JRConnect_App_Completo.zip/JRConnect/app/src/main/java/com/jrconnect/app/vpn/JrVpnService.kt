package com.jrconnect.app.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.core.app.NotificationCompat
import com.jrconnect.app.MainActivity
import com.jrconnect.app.R
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.InetSocketAddress
import java.nio.ByteBuffer
import java.nio.channels.DatagramChannel

class JrVpnService : VpnService() {

    companion object {
        private const val TAG = "JrVpnService"
        private const val CHANNEL_ID = "jr_vpn_channel"
        private const val NOTIFICATION_ID = 1001
        const val ACTION_START = "com.jrconnect.app.START_VPN"
        const val ACTION_STOP = "com.jrconnect.app.STOP_VPN"
        const val EXTRA_SERVER_HOST = "server_host"
        const val EXTRA_SERVER_PORT = "server_port"
        const val EXTRA_USERNAME = "username"
        const val EXTRA_PASSWORD = "password"
        const val EXTRA_PROTOCOL = "protocol"
        const val EXTRA_UUID = "uuid"
        const val EXTRA_SNI = "sni"
        const val EXTRA_CONFIG_NAME = "config_name"

        @Volatile var isRunning = false
        @Volatile var connectedConfigName = ""
    }

    private var vpnInterface: ParcelFileDescriptor? = null
    private var vpnThread: Thread? = null
    private var isActive = false

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val serverHost = intent.getStringExtra(EXTRA_SERVER_HOST) ?: ""
                val serverPort = intent.getIntExtra(EXTRA_SERVER_PORT, 0)
                val username = intent.getStringExtra(EXTRA_USERNAME) ?: ""
                val password = intent.getStringExtra(EXTRA_PASSWORD) ?: ""
                val protocol = intent.getStringExtra(EXTRA_PROTOCOL) ?: ""
                val uuid = intent.getStringExtra(EXTRA_UUID) ?: ""
                val sni = intent.getStringExtra(EXTRA_SNI) ?: ""
                val configName = intent.getStringExtra(EXTRA_CONFIG_NAME) ?: "JR Connect"

                startForeground(NOTIFICATION_ID, buildNotification(configName, "Conectando..."))
                startVpn(serverHost, serverPort, username, password, protocol, uuid, sni, configName)
            }
            ACTION_STOP -> stopVpn()
        }
        return START_STICKY
    }

    private fun startVpn(
        serverHost: String,
        serverPort: Int,
        username: String,
        password: String,
        protocol: String,
        uuid: String,
        sni: String,
        configName: String
    ) {
        vpnThread = Thread {
            try {
                Log.d(TAG, "Iniciando VPN: $configName | $protocol | $serverHost:$serverPort")

                // ─── Configurar interface VPN ──────────────────────────────────
                val builder = Builder()
                    .setSession("JR Connect - $configName")
                    .addAddress("10.0.0.2", 24)
                    .addDnsServer("8.8.8.8")
                    .addDnsServer("8.8.4.4")
                    .addDnsServer("1.1.1.1")
                    .addRoute("0.0.0.0", 0)
                    .setMtu(1500)

                vpnInterface = builder.establish()
                isActive = true
                isRunning = true
                connectedConfigName = configName

                updateNotification(configName, "Conectado ✓")

                // ─── Loop de leitura de pacotes ────────────────────────────────
                val inputStream = FileInputStream(vpnInterface!!.fileDescriptor)
                val outputStream = FileOutputStream(vpnInterface!!.fileDescriptor)
                val packet = ByteBuffer.allocate(32767)

                // Conecta ao servidor remoto via UDP (protocolo base)
                val tunnel = DatagramChannel.open()
                protect(tunnel.socket())

                if (serverHost.isNotEmpty() && serverPort > 0) {
                    tunnel.connect(InetSocketAddress(serverHost, serverPort))
                    // Handshake de autenticação
                    val authPayload = buildAuthPayload(username, password, uuid, protocol)
                    tunnel.write(ByteBuffer.wrap(authPayload))
                }

                Log.d(TAG, "VPN estabelecida com sucesso!")

                while (isActive) {
                    packet.clear()
                    val length = inputStream.read(packet.array())
                    if (length > 0) {
                        packet.limit(length)
                        // Encaminha pacote para o servidor
                        if (serverHost.isNotEmpty() && tunnel.isConnected) {
                            try { tunnel.write(packet) } catch (e: Exception) { /* ignora */ }
                        }
                        packet.clear()
                    }

                    // Recebe pacotes do servidor
                    if (serverHost.isNotEmpty() && tunnel.isConnected) {
                        try {
                            val recv = tunnel.receive(packet)
                            if (recv != null && packet.position() > 0) {
                                outputStream.write(packet.array(), 0, packet.position())
                            }
                        } catch (e: Exception) { /* ignora */ }
                    }

                    Thread.sleep(1)
                }

                tunnel.close()
            } catch (e: Exception) {
                Log.e(TAG, "Erro na VPN: ${e.message}", e)
                isRunning = false
                connectedConfigName = ""
            }
        }
        vpnThread?.isDaemon = true
        vpnThread?.start()
    }

    private fun buildAuthPayload(
        username: String,
        password: String,
        uuid: String,
        protocol: String
    ): ByteArray {
        val payload = when (protocol.lowercase()) {
            "v2ray", "vmess", "vless", "xray" -> {
                """{"type":"auth","uuid":"$uuid","user":"$username","pass":"$password"}"""
            }
            "ssh" -> {
                "SSH-2.0-JRConnect\r\nuser=$username&pass=$password"
            }
            else -> {
                "CONNECT $username:$password HTTP/1.1\r\n\r\n"
            }
        }
        return payload.toByteArray(Charsets.UTF_8)
    }

    fun stopVpn() {
        isActive = false
        isRunning = false
        connectedConfigName = ""
        try {
            vpnThread?.interrupt()
            vpnInterface?.close()
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao parar VPN: ${e.message}")
        }
        vpnInterface = null
        vpnThread = null
        stopForeground(true)
        stopSelf()
    }

    private fun buildNotification(configName: String, status: String): Notification {
        createNotificationChannel()
        val intent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, JrVpnService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPending = PendingIntent.getService(
            this, 1, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("JR Connect")
            .setContentText("$configName - $status")
            .setSmallIcon(R.drawable.ic_vpn_notification)
            .setContentIntent(pendingIntent)
            .addAction(R.drawable.ic_vpn_notification, "Desconectar", stopPending)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
    }

    private fun updateNotification(configName: String, status: String) {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIFICATION_ID, buildNotification(configName, status))
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "JR Connect VPN",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "JR Connect VPN Service"
            }
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        stopVpn()
        super.onDestroy()
    }
}
