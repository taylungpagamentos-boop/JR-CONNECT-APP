package com.jrconnect.app.api.models

import com.google.gson.annotations.SerializedName

data class ApiResponse<T>(
    @SerializedName("data") val data: T? = null,
    @SerializedName("message") val message: String = "",
    @SerializedName("success") val success: Boolean = false,
    @SerializedName("total") val total: Int = 0,
    @SerializedName("status") val status: String = ""
)

data class ApiListResponse<T>(
    @SerializedName("data") val data: List<T> = emptyList(),
    @SerializedName("message") val message: String = "",
    @SerializedName("success") val success: Boolean = false,
    @SerializedName("total") val total: Int = 0
)

data class SseTokenResponse(
    @SerializedName("token") val token: String = ""
)
