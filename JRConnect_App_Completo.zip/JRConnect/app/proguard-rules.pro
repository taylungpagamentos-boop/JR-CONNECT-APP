# Add project specific ProGuard rules here.
-keep class com.jrconnect.app.api.models.** { *; }
-keep class retrofit2.** { *; }
-keep class okhttp3.** { *; }
-keepattributes *Annotation*
-keepattributes Signature
