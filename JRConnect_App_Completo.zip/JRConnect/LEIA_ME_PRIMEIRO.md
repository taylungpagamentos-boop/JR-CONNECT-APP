# 📱 JR Connect - Internet Super Rápida
## Guia Completo de Compilação no Android Studio

---

## 🚀 PASSO A PASSO PARA COMPILAR

### 1️⃣ Instale o Android Studio
- Baixe em: https://developer.android.com/studio
- Instale normalmente (Next, Next, Finish)
- Aguarde baixar os SDKs automaticamente

### 2️⃣ Abra o projeto
1. Abra o Android Studio
2. Clique em **"Open"** (NÃO em New Project)
3. Navegue até a pasta **JRConnect** (esta pasta)
4. Clique em **OK**
5. Aguarde o Gradle sincronizar (pode demorar 2-5 minutos na primeira vez)

### 3️⃣ Adicione as imagens da sua marca (IMPORTANTE!)
Substitua os arquivos na pasta `app/src/main/res/drawable/`:
- **`logo_jr_connect.png`** → Sua logo JR Connect (PNG, ~280x140px)
- **`bg_space.png`** → Imagem de fundo (PNG, ~1080x1920px)
- **`ic_vivo.png`** → Ícone da VIVO (~44x44px)
- **`ic_tim.png`** → Ícone da TIM (~44x44px)
- **`ic_claro.png`** → Ícone da CLARO (~44x44px)

> ⚠️ Se quiser usar PNG ao invés de XML:
> 1. Copie seu PNG para a pasta drawable
> 2. Renomeie para o mesmo nome (ex: logo_jr_connect.png)
> 3. Delete o arquivo .xml com o mesmo nome
> 4. O Android Studio vai usar automaticamente

### 4️⃣ Configure o ícone do app
1. Clique com botão direito em `app/src/main/res`
2. Selecione **New → Image Asset**
3. Em "Icon Type" selecione "Launcher Icons (Adaptive and Legacy)"
4. Clique no ícone de pasta ao lado de "Source Asset"
5. Selecione sua logo JR Connect
6. Clique em "Next" → "Finish"

### 5️⃣ Gere o APK
1. No menu superior: **Build → Build Bundle(s) / APK(s) → Build APK(s)**
2. Aguarde a compilação (2-3 minutos)
3. Clique em **"locate"** no popup que aparecer
4. Seu APK estará em: `app/build/outputs/apk/debug/app-debug.apk`

### 6️⃣ Instale no celular
1. Copie o APK para seu celular (WhatsApp, Telegram, pendrive, etc.)
2. No celular: Configurações → Segurança → Fontes Desconhecidas (ativar)
3. Abra o arquivo APK e instale

---

## 🔧 CONFIGURAÇÕES DO APP

### API Key (já configurada)
- Arquivo: `app/src/main/java/com/jrconnect/app/api/ApiClient.kt`
- A chave já está inserida corretamente

### WhatsApp de Suporte (já configurado)
- Link: https://wa.me/qr/E7XKJ3DND6CMI1
- Arquivo: `app/src/main/res/values/strings.xml`

### Para mudar o nome do app
- Arquivo: `app/src/main/res/values/strings.xml`
- Linha: `<string name="app_name">JR Connect</string>`

---

## 📋 ESTRUTURA DO PROJETO

```
JRConnect/
├── app/src/main/
│   ├── java/com/jrconnect/app/
│   │   ├── SplashActivity.kt          ← Tela de abertura
│   │   ├── MainActivity.kt            ← Tela principal
│   │   ├── ConfigSelectionActivity.kt ← Lista de configurações
│   │   ├── api/
│   │   │   ├── ApiClient.kt           ← Configuração da API
│   │   │   ├── ApiService.kt          ← Endpoints da API
│   │   │   └── models/                ← Modelos de dados
│   │   ├── adapter/
│   │   │   └── ConfigAdapter.kt       ← Lista de configs
│   │   ├── vpn/
│   │   │   └── JrVpnService.kt        ← Serviço VPN
│   │   └── utils/
│   │       └── NetworkUtils.kt        ← Utilitários de rede
│   └── res/
│       ├── layout/                    ← Telas XML
│       ├── drawable/                  ← Ícones e backgrounds
│       └── values/                    ← Cores, strings, temas
```

---

## ❓ PROBLEMAS COMUNS

**Gradle sync falhou:**
- Verifique sua conexão com internet
- Clique em File → Invalidate Caches → Restart

**"Cannot resolve symbol R":**
- Clique em Build → Clean Project
- Depois Build → Rebuild Project

**Erro de versão do SDK:**
- Clique em Tools → SDK Manager
- Instale o Android SDK 34

---

## 📞 SUPORTE
WhatsApp: https://wa.me/qr/E7XKJ3DND6CMI1

